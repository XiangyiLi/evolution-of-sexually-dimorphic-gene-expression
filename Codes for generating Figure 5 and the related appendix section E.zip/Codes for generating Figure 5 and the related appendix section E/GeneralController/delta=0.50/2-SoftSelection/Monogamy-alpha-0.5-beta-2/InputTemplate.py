import ThetaDiff_gamma_delta
numInd=5000
numLoci=40
tMax=2000
delta=0.5
gamma=2
alpha=0.5
beta=2
LifeCycleMode='a'
SelectionScale='s'

ThetaDiff_gamma_delta.ThetaDiff_gamma_delta(numInd, numLoci, tMax, delta, gamma, alpha, beta, LifeCycleMode, SelectionScale)