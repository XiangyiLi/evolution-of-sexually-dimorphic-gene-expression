import ChangeDeathRate_Polyandry
numInd=5000 
numLoci=40
tMax=2000
alpha=2
beta=2
#gamma=3
delta=0.75
#deathRate=0.3
SelectionScale='h'

ChangeDeathRate_Polyandry.ChangeDeathRate_Polyandry(numInd, numLoci, tMax, alpha, beta, gamma, delta, deathRate, SelectionScale)