declare -a gammaArray=($(seq 0 0.25 6.001))

for gamma in "${gammaArray[@]}"
do
	a="gamma="
	inputLine=$a$gamma
	echo $inputLine
	sed "6s/.*/$inputLine/" InputTemplate.py > "delta-$delta-gamma-$gamma.py"
	echo "#!/bin/bash" > "job_delta-$delta-gamma-$gamma.sh"
	echo "#SBATCH -n 1" >> "job_delta-$delta-gamma-$gamma.sh"
	echo "#SBATCH --mem 2000" >> "job_delta-$delta-gamma-$gamma.sh"
	echo "#SBATCH --time 10:0:0" >> "job_delta-$delta-gamma-$gamma.sh"
	echo "#SBATCH --exclude=node01,node02,node03" >> "job_delta-$delta-gamma-$gamma.sh"
	echo "#SBATCH --nice=100000" >> "job_delta-$delta-gamma-$gamma.sh"
	echo "python3 delta-$delta-gamma-$gamma.py" >> "job_delta-$delta-gamma-$gamma.sh"
	sbatch "job_delta-$delta-gamma-$gamma.sh"
done

