#alpha is the intensity of female fecundity competition 
#beta is the intensity of male mating competition
#gamma is the selection intensity on female viability under sexual harrasement
#delta is the proportion of loci that are expressed in both sexes
#deathRate is the proportion of females that die from male harassment under polyandry
#SelectionScale: 'h'->hard selection on females, 's'->soft selection on females
def ChangeDeathRate_Polyandry(numInd, numLoci, tMax, alpha, beta, gamma, delta, deathRate, SelectionScale):
    
    import numpy as np

    #record start
    tStaRec=int(tMax/2)

    #polyandry sex ratio (number of males in each mating group)
    polyandrySexRatio=5

    #total number of individuals under polyandry 
    numTotalPolyandry=numInd*(1+polyandrySexRatio)

    #mutation rate: the mutated allele takes a uniformly distributed random number between -1 and 1
    mutationRate=0.01
    
            
    #number of alleles (at diploid loci) that are expressed in one of the sexes
    u=2*int(numLoci*(1-delta)/2)
    #number of alleles that are expressed in both sexes
    v=2*numLoci-2*u
    #general controller loci only expressed in females
    LociExpOnlyF=np.arange(0,u,1)
    #general controller loci expressed in both sexes
    LociExpBothSex=np.arange(u,u+v,1)
    #general controller loci expressed in males
    LociExpOnlyM=np.arange(u+v,2*u+v,1)

    #List of the location of different types of loci
    LociList=[LociExpOnlyF,LociExpBothSex,LociExpOnlyM]
    numLociTypes=len(LociList)

    #initialize the genome of females and males
    #in the population, rows [0:numInd] are females, the rest are males.
    #In all treatments, the number of females in a metapopulation is the same
    IDfemales=np.arange(0,numInd)
    IDmales=np.arange(numInd,numTotalPolyandry)
    newPop=np.random.uniform(-1,1,(numTotalPolyandry,numLoci*2))


    #Record the population median condition of males and females
    ThetaMedList=np.zeros(shape=(tMax,2))

    #Life cycles
    t=0
    while t< tMax:

        Pop=newPop

        #determine the sex-specific gene expression level for each sex
        #female-biased (f) gene expression level of each female (F)
        phi_f_F=1+np.sum(Pop[IDfemales][:,np.append(LociExpOnlyF,LociExpBothSex)],axis=1)/(u+v)
        #male-biased (m) gene expression level of each female (F)
        phi_m_F=-1-np.sum(Pop[IDfemales][:,np.append(LociExpOnlyF,LociExpBothSex)],axis=1)/(u+v)
        #female-biased (f) gene expression level of each male (M)
        phi_f_M=-1+np.sum(Pop[IDmales][:,np.append(LociExpBothSex,LociExpOnlyM)],axis=1)/(u+v)
        #male-biased (m) gene expression levle of each male (M)
        phi_m_M=1-np.sum(Pop[IDmales][:,np.append(LociExpBothSex,LociExpOnlyM)],axis=1)/(u+v)

        #Condition of each female
        theta_F=phi_f_F-phi_m_F
        #Condition of each male
        theta_M=phi_m_M-phi_f_M
        
        #Collect population statistics
        #List of theta values
        ThetaMedList[t,:]=[np.median(theta_F),np.median(theta_M)]

        #female mortality due to male harrassment
        #High condition females are less likely to die
        #dead females have a condition of 0
        numSurvived=int(numInd*(1-deathRate))
        femRelativeCondition=theta_F**gamma/sum(theta_F**gamma)
        SurvivedFemIDs=np.random.choice(IDfemales, numSurvived, replace=False, p=femRelativeCondition)
        DeadFemIDs=np.setdiff1d(IDfemales,SurvivedFemIDs)
        theta_F[DeadFemIDs]=0


        #reproduction
        if SelectionScale=='h': #females are under hard selection

            #Probability of each female to be chosen as mother
            momProbList=theta_F**alpha/sum(theta_F**alpha)
            MomIDs=np.random.choice(IDfemales, numTotalPolyandry, replace=True, p=momProbList)
            numOffsEachGroup=np.histogram(MomIDs,bins=np.arange(0,numInd+1,1))[0]
            DadIDs=[]
            for i in np.arange(0,numInd):
                #possible father IDs
                possibleDadIDs=numInd+np.arange(i*polyandrySexRatio,(i+1)*polyandrySexRatio)
                dadProbList=theta_M[possibleDadIDs-numInd]**beta/sum(theta_M[possibleDadIDs-numInd]**beta)
                newDads=np.random.choice(possibleDadIDs,numOffsEachGroup[i],replace=True,p=dadProbList)
                DadIDs=np.append(DadIDs,newDads)

            MomIDs=MomIDs.astype(int)      
            DadIDs=DadIDs.astype(int)
            #shuffle MomIDs and DadIDs but keep the couple combination unchanged
            Couples=np.transpose([MomIDs,DadIDs])
            np.random.shuffle(Couples)
            MomIDs=Couples[:,0]
            DadIDs=Couples[:,1]



        else: #SelectionScale=='s': females are under soft selection
            MomIDs=[]
            DadIDs=[]
            numOffs=(int(1/(1-deathRate))+1)*6
            for i in np.arange(0,numInd):
                if theta_F[i]!=0:
                    newMoms=np.repeat(i,numOffs) #10 female offspring and 50 male offspring
                    MomIDs=np.append(MomIDs,newMoms)
                    possibleDadIDs=numInd+np.arange(i*polyandrySexRatio,(i+1)*polyandrySexRatio)
                    dadProbList=theta_M[possibleDadIDs-numInd]**beta/sum(theta_M[possibleDadIDs-numInd]**beta)
                    newDads=np.random.choice(possibleDadIDs,numOffs,replace=True,p=dadProbList)
                    DadIDs=np.append(DadIDs,newDads)
            MomIDs=MomIDs.astype(int)
            DadIDs=DadIDs.astype(int)
            #shuffle MomIDs and DadIDs but keep the couple combination unchanged
            Couples=np.transpose([MomIDs,DadIDs])
            np.random.shuffle(Couples)
            MomIDs=Couples[0:numTotalPolyandry,0]
            DadIDs=Couples[0:numTotalPolyandry,1]


        #Build the "genome" of the next generation
        momMatrix=Pop[MomIDs]
        dadMatrix=Pop[DadIDs]
        #only one allele is selected from mom at each locus: 
        #if allele1 is selected, allele2 cannot be selected, vice versa
        fromMomAllele1=np.random.randint(low=0,high=2,size=(numTotalPolyandry,numLoci))
        momAlleles=np.empty((numTotalPolyandry,numLoci*2))
        fromMomAllele2=1-fromMomAllele1
        momAlleles[:,::2]=fromMomAllele1
        momAlleles[:,1::2]=fromMomAllele2
        #the other allele must come from dad
        dadAlleles=1-momAlleles
        #assemble the genome of the offspring
        newPop=momAlleles*momMatrix + dadAlleles*dadMatrix

        #mutation happens
        mutOrNot = np.random.uniform(low=0,high=1,size=(numTotalPolyandry,numLoci*2)) < mutationRate
        newPop=np.random.uniform(-1,1,(numTotalPolyandry,numLoci*2))*mutOrNot + newPop*(1-mutOrNot)


        # generation turnover
        t+=1

    #difference between female and male condition
    diffFM=np.median(ThetaMedList[tStaRec:tMax,0])-np.median(ThetaMedList[tStaRec:tMax,1])
    ThetaDiffList=[gamma, deathRate, diffFM]


    #save the results
    np.savetxt("Polyandry-FemSelection-"+SelectionScale+"-alpha-"+str(alpha)+"-beta-"+str(beta)+"-delta-"+str(delta)+"-gamma-"+str(gamma)+"-deathRate-"+str(deathRate)+".csv",ThetaDiffList,delimiter=",")
