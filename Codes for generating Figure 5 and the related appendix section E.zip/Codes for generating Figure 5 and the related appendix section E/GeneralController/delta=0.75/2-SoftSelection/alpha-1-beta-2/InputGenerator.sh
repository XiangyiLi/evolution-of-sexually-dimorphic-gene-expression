declare -a gammaArray=($(seq 0 0.25 6.001))
declare -a deathRateArray=($(seq 0.2 0.025 0.801))


for deathRate in "${deathRateArray[@]}"
do
	for gamma in "${gammaArray[@]}"
	do
		a="ChangeDeathRate_Polyandry.ChangeDeathRate_Polyandry(numInd, numLoci, tMax, alpha, beta, "
		b=", delta, "
		c=", SelectionScale)"
		inputLine=$a$gamma$b$deathRate$c
		echo $inputLine
		sed "12s/.*/$inputLine/" InputTemplate.py > "deathRate-$deathRate-gamma-$gamma.py"
		echo "#!/bin/bash" > "job_deathRate-$deathRate-gamma-$gamma.sh"
		echo "#SBATCH -n 1" >> "job_deathRate-$deathRate-gamma-$gamma.sh"
		echo "#SBATCH --mem 2000" >> "job_deathRate-$deathRate-gamma-$gamma.sh"
		echo "#SBATCH --time 10:0:0" >> "job_deathRate-$deathRate-gamma-$gamma.sh"
		echo "#SBATCH --exclude=node01,node02,node03" >> "job_deathRate-$deathRate-gamma-$gamma.sh"
		echo "#SBATCH --nice=100000" >> "job_deathRate-$deathRate-gamma-$gamma.sh"
		echo "python3 deathRate-$deathRate-gamma-$gamma.py" >> "job_deathRate-$deathRate-gamma-$gamma.sh"
		sbatch "job_deathRate-$deathRate-gamma-$gamma.sh"
	done
done
