def Traj_GeneralController(numInd, numLoci, tMax, alpha, beta, gamma, delta, deathRateA, deathRateB, deathRateC, deathRateD, LifeCycleMode, SelectionScale):

    import numpy as np

    #number of same sex individuals in a polygamy group
    polygamyGroupSize=5
    #polyandry sex ratio (number of males in each mating group)
    polyandrySexRatio=5
    #polygyny sex ratio (number of females in each mating group under polygyny)
    polygynySexRatio=5

    #mutation rate: the mutated allele takes a uniformly distributed random number between -1 and 1
    mutationRate=0.01
    
    #number of alleles (at diploid loci) that are expressed in one of the sexes
    u=2*int(numLoci*(1-delta)/2)
    #number of alleles that are expressed in both sexes
    v=2*numLoci-2*u
    #general controller loci only expressed in females
    LociExpOnlyF=np.arange(0,u,1)
    #general controller loci expressed in both sexes
    LociExpBothSex=np.arange(u,u+v,1)
    #general controller loci expressed in males
    LociExpOnlyM=np.arange(u+v,2*u+v,1)

    #List of the location of different types of loci
    LociList=[LociExpOnlyF,LociExpBothSex,LociExpOnlyM]
    numLociTypes=len(LociList)
    
    #initialize the genome of females and males
    #in the population, rows [0:numInd] are females, the rest are males.
    #In all treatments, the number of females in a metapopulation is the same
    IDfemales=np.arange(0,numInd)
    if (LifeCycleMode=='a' or LifeCycleMode=='b'): 
        #under monogamy and polygamy, two sexes have the same number
        IDmales=np.arange(numInd,2*numInd)
        newPop=np.random.uniform(-1,1,(numInd*2,numLoci*2))
    elif LifeCycleMode=='c': #under polyandry, the number of males is 5 times of females
        numTotalPolyandry=numInd*(1+polyandrySexRatio)
        IDmales=np.arange(numInd,numTotalPolyandry)
        newPop=np.random.uniform(-1,1,(numTotalPolyandry,numLoci*2))
    else: # under polygyny, the number of males is 1/5 of females
        numTotalPolygyny=numInd+int(numInd/polygynySexRatio)
        IDmales=np.arange(numInd,numTotalPolygyny)
        newPop=np.random.uniform(-1,1,(numTotalPolygyny,numLoci*2))


    #Initialize the record tables
    LociMedList=np.zeros(shape=(tMax,numLociTypes))
    PhiMedList=np.zeros(shape=(tMax,4))
    ThetaMedList=np.zeros(shape=(tMax,2))

    #Life cycles
    t=0
    while t< tMax:

        Pop=newPop

        #determine the sex-specific gene expression level for each sex
        #female-biased (f) gene expression level of each female (F)
        phi_f_F=1+np.sum(Pop[IDfemales][:,np.append(LociExpOnlyF,LociExpBothSex)],axis=1)/(u+v)
        #male-biased (m) gene expression level of each female (F)
        phi_m_F=-1-np.sum(Pop[IDfemales][:,np.append(LociExpOnlyF,LociExpBothSex)],axis=1)/(u+v)
        #female-biased (f) gene expression level of each male (M)
        phi_f_M=-1+np.sum(Pop[IDmales][:,np.append(LociExpBothSex,LociExpOnlyM)],axis=1)/(u+v)
        #male-biased (m) gene expression levle of each male (M)
        phi_m_M=1-np.sum(Pop[IDmales][:,np.append(LociExpBothSex,LociExpOnlyM)],axis=1)/(u+v)

        #Condition of each female
        theta_F=phi_f_F-phi_m_F
        #Condition of each male
        theta_M=phi_m_M-phi_f_M
        
        #Collect population statistics
        #List of different types of loci
        for i in np.arange(0,numLociTypes):
            LociMedList[t,i]=np.median(Pop[:,LociList[i]])

        #List of phi values
        PhiMedList[t,:]=[np.median(phi_f_F),np.median(phi_m_F),np.median(phi_f_M),np.median(phi_m_M)]

        #List of theta values
        ThetaMedList[t,:]=[np.median(theta_F),np.median(theta_M)]

        #female mortality due to male harrassment
        #High condition females are less likely to die
        #dead females have a condition of 0
        if LifeCycleMode=='a': #monogamy
            numSurvived=int(numInd*(1-deathRateA))
        elif LifeCycleMode=='b': #polygamy
            numSurvived=int(numInd*(1-deathRateB))
        elif LifeCycleMode=='c': #polyandry
            numSurvived=int(numInd*(1-deathRateC))
        else: #polygyny
            numSurvived=int(numInd*(1-deathRateD))
        femRelativeCondition=theta_F**gamma/sum(theta_F**gamma)
        SurvivedFemIDs=np.random.choice(IDfemales, numSurvived, replace=False, p=femRelativeCondition)
        DeadFemIDs=np.setdiff1d(IDfemales,SurvivedFemIDs)
        theta_F[DeadFemIDs]=0


        #reproduction
        if SelectionScale=='h': #females are under hard selection

            #Probability of each female to be chosen as mother
            momProbList=theta_F**alpha/sum(theta_F**alpha)

            if LifeCycleMode == 'a':
                MomIDs=np.random.choice(IDfemales, numInd*2, replace=True, p=momProbList)
                #Father is the given partner of the chosen mother
                DadIDs=MomIDs+numInd

            elif LifeCycleMode == 'b':
                MomIDs=np.random.choice(IDfemales, numInd*2, replace=True, p=momProbList)
                numGroups=int(numInd/polygamyGroupSize)
                numOffsEachGroup=np.histogram(MomIDs,bins=np.arange(0,numInd+1,polygamyGroupSize))[0]
                DadIDs=[]
                for i in np.arange(0,numGroups):
                    #possible father IDs
                    possibleDadIDs=numInd+np.arange(i*polygamyGroupSize,(i+1)*polygamyGroupSize)
                    dadProbList=theta_M[possibleDadIDs-numInd]**beta/sum(theta_M[possibleDadIDs-numInd]**beta)
                    newDads=np.random.choice(possibleDadIDs,numOffsEachGroup[i],replace=True,p=dadProbList)
                    DadIDs=np.append(DadIDs,newDads)

            elif LifeCycleMode =='c':
                MomIDs=np.random.choice(IDfemales, numTotalPolyandry, replace=True, p=momProbList)
                numOffsEachGroup=np.histogram(MomIDs,bins=np.arange(0,numInd+1,1))[0]
                DadIDs=[]
                for i in np.arange(0,numInd):
                    #possible father IDs
                    possibleDadIDs=numInd+np.arange(i*polyandrySexRatio,(i+1)*polyandrySexRatio)
                    dadProbList=theta_M[possibleDadIDs-numInd]**beta/sum(theta_M[possibleDadIDs-numInd]**beta)
                    newDads=np.random.choice(possibleDadIDs,numOffsEachGroup[i],replace=True,p=dadProbList)
                    DadIDs=np.append(DadIDs,newDads)

            else: #when LifeCycleMode =='d': polygyny
                MomIDs=np.random.choice(IDfemales, numTotalPolygyny, replace=True, p=momProbList)
                numGroups=int(numInd/polygynySexRatio)
                numOffsEachGroup=np.histogram(MomIDs,bins=np.arange(0,numInd+1,polygynySexRatio))[0]
                DadIDs=[]
                for i in np.arange(0,numGroups):
                    #all offspring produced in the same group have the same dad
                    newDads=np.repeat(numInd+i,numOffsEachGroup[i]) 
                    DadIDs=np.append(DadIDs,newDads)

            MomIDs=MomIDs.astype(int)      
            DadIDs=DadIDs.astype(int)
            #shuffle MomIDs and DadIDs but keep the couple combination unchanged
            Couples=np.transpose([MomIDs,DadIDs])
            np.random.shuffle(Couples)
            MomIDs=Couples[:,0]
            DadIDs=Couples[:,1]



        else: #SelectionScale=='s': females are under soft selection
            MomIDs=[]
            DadIDs=[]
            if LifeCycleMode == 'a': #monogamy
                for i in np.arange(0,numInd):
                    if theta_F[i]!=0: # the female is not dead
                        newMoms=np.repeat(i,6)#each group produce 3 offspring of each sex, so 6 in total
                        newDads=np.repeat(numInd+i,6)
                        MomIDs=np.append(MomIDs,newMoms)
                        DadIDs=np.append(DadIDs,newDads)
                MomIDs=MomIDs.astype(int)
                DadIDs=DadIDs.astype(int)
                #shuffle MomIDs and DadIDs but keep the couple combination unchanged
                Couples=np.transpose([MomIDs,DadIDs])
                np.random.shuffle(Couples)
                MomIDs=Couples[0:2*numInd,0]
                DadIDs=Couples[0:2*numInd,1]

            elif LifeCycleMode =='b': #polygamy
                numGroups=int(numInd/polygamyGroupSize)           
                for i in np.arange(0,numGroups):
                    possibleMomIDs=np.arange(i*polygamyGroupSize,(i+1)*polygamyGroupSize)
                    momProbList=theta_F[possibleMomIDs]**alpha/sum(theta_F[possibleMomIDs]**alpha)
                    newMoms=np.random.choice(possibleMomIDs, 30, replace=True, p=momProbList)
                    MomIDs=np.append(MomIDs,newMoms)
                    possibleDadIDs=numInd+np.arange(i*polygamyGroupSize,(i+1)*polygamyGroupSize)
                    dadProbList=theta_M[possibleDadIDs-numInd]**beta/sum(theta_M[possibleDadIDs-numInd]**beta)
                    newDads=np.random.choice(possibleDadIDs,30,replace=True,p=dadProbList)
                    DadIDs=np.append(DadIDs,newDads)
                MomIDs=MomIDs.astype(int)
                DadIDs=DadIDs.astype(int)
                #shuffle MomIDs and DadIDs but keep the couple combination unchanged
                Couples=np.transpose([MomIDs,DadIDs])
                np.random.shuffle(Couples)
                MomIDs=Couples[0:2*numInd,0]
                DadIDs=Couples[0:2*numInd,1]

            elif LifeCycleMode=='c':
                numOffs=(int(1/(1-deathRateC))+1)*6
                for i in np.arange(0,numInd):
                    if theta_F[i]!=0:
                        newMoms=np.repeat(i,numOffs) #3 female offspring and 15 male offspring
                        MomIDs=np.append(MomIDs,newMoms)
                        possibleDadIDs=numInd+np.arange(i*polyandrySexRatio,(i+1)*polyandrySexRatio)
                        dadProbList=theta_M[possibleDadIDs-numInd]**beta/sum(theta_M[possibleDadIDs-numInd]**beta)
                        newDads=np.random.choice(possibleDadIDs,numOffs,replace=True,p=dadProbList)
                        DadIDs=np.append(DadIDs,newDads)
                MomIDs=MomIDs.astype(int)
                DadIDs=DadIDs.astype(int)
                #shuffle MomIDs and DadIDs but keep the couple combination unchanged
                Couples=np.transpose([MomIDs,DadIDs])
                np.random.shuffle(Couples)
                MomIDs=Couples[0:numTotalPolyandry,0]
                DadIDs=Couples[0:numTotalPolyandry,1]

            else: #LifeCycleMode=='d': polygyny
                numGroups=int(numInd/polygynySexRatio)
                for i in np.arange(0,numGroups):
                    possibleMomIDs=np.arange(i*polygynySexRatio,(i+1)*polygynySexRatio)
                    momProbList=theta_F[possibleMomIDs]**alpha/sum(theta_F[possibleMomIDs]**alpha)
                    #each group produce 15 female and 3 male offspring on average
                    newMoms=np.random.choice(possibleMomIDs, 18, replace=True, p=momProbList) 
                    MomIDs=np.append(MomIDs,newMoms)
                    #all offspring produced in the same group have the same dad
                    newDads=np.repeat(numInd+i,18) 
                    DadIDs=np.append(DadIDs,newDads)
                MomIDs=MomIDs.astype(int)
                DadIDs=DadIDs.astype(int)
                #shuffle MomIDs and DadIDs but keep the couple combination unchanged
                Couples=np.transpose([MomIDs,DadIDs])
                np.random.shuffle(Couples)
                MomIDs=Couples[0:numTotalPolygyny,0]
                DadIDs=Couples[0:numTotalPolygyny,1]



        #Build the "genome" of the next generation
        momMatrix=Pop[MomIDs]
        dadMatrix=Pop[DadIDs]
        #only one allele is selected from mom at each locus: 
        #if allele1 is selected, allele2 cannot be selected, vice versa

        if (LifeCycleMode=='a' or LifeCycleMode=='b'): #monogamy or polygamy
            fromMomAllele1=np.random.randint(low=0,high=2,size=(numInd*2,numLoci))
            momAlleles=np.empty((numInd*2,numLoci*2))
        elif LifeCycleMode=='c': #polyandry
            fromMomAllele1=np.random.randint(low=0,high=2,size=(numTotalPolyandry,numLoci))
            momAlleles=np.empty((numTotalPolyandry,numLoci*2))
        else: #LifeCycleMode=='d': polygyny
            fromMomAllele1=np.random.randint(low=0,high=2,size=(numTotalPolygyny,numLoci))
            momAlleles=np.empty((numTotalPolygyny,numLoci*2))

        fromMomAllele2=1-fromMomAllele1
        momAlleles[:,::2]=fromMomAllele1
        momAlleles[:,1::2]=fromMomAllele2
        #the other allele must come from dad
        dadAlleles=1-momAlleles
        #assemble the genome of the offspring
        newPop=momAlleles*momMatrix + dadAlleles*dadMatrix

        #mutation happens
        if (LifeCycleMode=='a' or LifeCycleMode=='b'):
            mutOrNot = np.random.uniform(low=0,high=1,size=(numInd*2,numLoci*2)) < mutationRate
            newPop=np.random.uniform(-1,1,(numInd*2,numLoci*2))*mutOrNot + newPop*(1-mutOrNot)
        elif LifeCycleMode=='c':
            mutOrNot = np.random.uniform(low=0,high=1,size=(numTotalPolyandry,numLoci*2)) < mutationRate
            newPop=np.random.uniform(-1,1,(numTotalPolyandry,numLoci*2))*mutOrNot + newPop*(1-mutOrNot)
        else: #polygyny: LifeCycleMode=='d'
            mutOrNot = np.random.uniform(low=0,high=1,size=(numTotalPolygyny,numLoci*2)) < mutationRate
            newPop=np.random.uniform(-1,1,(numTotalPolygyny,numLoci*2))*mutOrNot + newPop*(1-mutOrNot)

        # generation turnover
        t+=1

    #Histogram of the number of offspring produced by each female
    numOffsEachFemale=np.histogram(MomIDs,bins=np.arange(0,numInd+1,1))[0]
    maxOffNum=max(numOffsEachFemale)
    histFemaleFecundity=np.histogram(numOffsEachFemale,bins=np.arange(0,maxOffNum+2,1))[0]

    #Histogram of the number of offspring produced by each male
    if (LifeCycleMode=='a' or LifeCycleMode=='b'):
        numOffsEachMale=np.histogram(DadIDs,bins=np.arange(numInd,2*numInd+1,1))[0]
    elif LifeCycleMode=='c': #polyandry
        numOffsEachMale=np.histogram(DadIDs,bins=np.arange(numInd,numTotalPolyandry+1,1))[0]
    else: #polygyny
        numOffsEachMale=np.histogram(DadIDs,bins=np.arange(numInd,numTotalPolygyny+1,1))[0]
    maxOffNum=max(numOffsEachMale)
    histMaleFecundity=np.histogram(numOffsEachMale,bins=np.arange(0,maxOffNum+2,1))[0]


    #save the results
    np.savetxt("LociMedList-alpha-"+str(alpha)+"-beta-"+str(beta)+"-gamma-"+str(gamma)+"-delta-"+str(delta)+"-deathRateC-"+str(deathRateC)+"-LifeCycle-"+LifeCycleMode+"-FemSelection-"+SelectionScale+".csv",LociMedList,delimiter=",")
    np.savetxt("PhiMedList-alpha-"+str(alpha)+"-beta-"+str(beta)+"-gamma-"+str(gamma)+"-delta-"+str(delta)+"-deathRateC-"+str(deathRateC)+"-LifeCycle-"+LifeCycleMode+"-FemSelection-"+SelectionScale+".csv",PhiMedList,delimiter=",")
    np.savetxt("ThetaMedList-alpha-"+str(alpha)+"-beta-"+str(beta)+"-gamma-"+str(gamma)+"-delta-"+str(delta)+"-deathRateC-"+str(deathRateC)+"-LifeCycle-"+LifeCycleMode+"-FemSelection-"+SelectionScale+".csv",ThetaMedList,delimiter=",")
    np.savetxt("HistFemaleFecundity-alpha-"+str(alpha)+"-beta-"+str(beta)+"-gamma-"+str(gamma)+"-delta-"+str(delta)+"-deathRateC-"+str(deathRateC)+"-LifeCycle-"+LifeCycleMode+"-FemSelection-"+SelectionScale+".csv",histFemaleFecundity,delimiter=",")
    np.savetxt("HistMaleFecundity-alpha-"+str(alpha)+"-beta-"+str(beta)+"-gamma-"+str(gamma)+"-delta-"+str(delta)+"-deathRateC-"+str(deathRateC)+"-LifeCycle-"+LifeCycleMode+"-FemSelection-"+SelectionScale+".csv",histMaleFecundity,delimiter=",")

