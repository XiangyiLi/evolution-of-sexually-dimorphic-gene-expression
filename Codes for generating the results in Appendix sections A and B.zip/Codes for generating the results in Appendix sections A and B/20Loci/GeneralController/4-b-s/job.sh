#!/bin/bash
#SBATCH -n 1
#SBATCH --mem 2000
#SBATCH --time 10:0:0
#SBATCH --exclude=node01,node02,node03
#SBATCH --nice=100000
python3 Input.py