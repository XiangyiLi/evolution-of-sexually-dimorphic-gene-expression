import Traj_GeneralController
import numpy as np

numInd=5000
numLoci=20
tMax=1000
alpha=1
beta=2
gamma=1
delta=0.6
LifeCycleMode='a'
SelectionScale='h'

#female death rate under monogamy
deathRateA=0.05
#female death rate under polygamy
deathRateB=np.sqrt(5)*deathRateA
#female death rate under polyandry
deathRateC=5*deathRateA
#female death rate under polygyny
deathRateD=deathRateA/np.sqrt(5)

Traj_GeneralController.Traj_GeneralController(numInd, numLoci, tMax, alpha, beta, gamma, delta, deathRateA, deathRateB, deathRateC, deathRateD, LifeCycleMode, SelectionScale)