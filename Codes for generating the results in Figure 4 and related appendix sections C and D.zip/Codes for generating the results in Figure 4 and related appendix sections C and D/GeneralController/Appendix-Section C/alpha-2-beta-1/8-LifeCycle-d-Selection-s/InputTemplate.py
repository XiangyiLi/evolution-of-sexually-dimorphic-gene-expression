import ThetaDiff_gamma_delta
numInd=5000
numLoci=40
tMax=15000
#delta=0.2
#gamma=2
alpha=2
beta=1
LifeCycleMode='d'
SelectionScale='s'

ThetaDiff_gamma_delta.ThetaDiff_gamma_delta(numInd, numLoci, tMax, delta, gamma, alpha, beta, LifeCycleMode, SelectionScale)