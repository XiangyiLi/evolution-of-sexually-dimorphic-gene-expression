import ThetaDiff_gamma_delta
numInd=5000
numLoci=40
tMax=5000
#delta=0.2
#gamma=2
alpha=3
beta=2
LifeCycleMode='c'
SelectionScale='h'

ThetaDiff_gamma_delta.ThetaDiff_gamma_delta(numInd, numLoci, tMax, delta, gamma, alpha, beta, LifeCycleMode, SelectionScale)