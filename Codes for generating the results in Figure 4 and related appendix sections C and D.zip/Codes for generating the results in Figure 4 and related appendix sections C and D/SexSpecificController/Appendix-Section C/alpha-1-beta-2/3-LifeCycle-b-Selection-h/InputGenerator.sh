declare -a deltaArray=($(seq 0 0.05 1.001))
declare -a gammaArray=($(seq 0 0.25 5.001))


for delta in "${deltaArray[@]}"
do
	for gamma in "${gammaArray[@]}"
	do
		a="ThetaDiff_SexSpecific_gamma_delta.ThetaDiff_SexSpecific_gamma_delta(numInd, numLoci, tMax,"
		b=", "
		c=", alpha, beta, LifeCycleMode, SelectionScale)"
		inputLine=$a$delta$b$gamma$c
		echo $inputLine
		sed "12s/.*/$inputLine/" InputTemplate.py > "delta-$delta-gamma-$gamma.py"
		echo "#!/bin/bash" > "job_delta-$delta-gamma-$gamma.sh"
		echo "#SBATCH -n 1" >> "job_delta-$delta-gamma-$gamma.sh"
		echo "#SBATCH --mem 2000" >> "job_delta-$delta-gamma-$gamma.sh"
		echo "#SBATCH --time 10:0:0" >> "job_delta-$delta-gamma-$gamma.sh"
		echo "#SBATCH --exclude=node01,node02,node03,node04" >> "job_delta-$delta-gamma-$gamma.sh"
		echo "#SBATCH --nice=100000" >> "job_delta-$delta-gamma-$gamma.sh"
		echo "python3 delta-$delta-gamma-$gamma.py" >> "job_delta-$delta-gamma-$gamma.sh"
		sbatch "job_delta-$delta-gamma-$gamma.sh"
	done
done
